import time
def getDetailsMap():
    details_in = open("details.in.txt", 'r')
    p = int(details_in.readline())
    hashmap = dict({})
    for i in range(p):
        line = details_in.readline()
        sep = line.split(',')
        hashmap[sep[0]] = line
    details_in.close()
    return hashmap
start = time.time()
ids_in = open("ids.in.txt", 'r')
n = int(ids_in.readline())
doc = getDetailsMap()
for i in range(n):
    id = ids_in.readline()
    result = doc[id.strip("\n")]
    if result:
        print(result.strip("\n"))
ids_in.close()

print("execution time : ", (time.time() - start))
