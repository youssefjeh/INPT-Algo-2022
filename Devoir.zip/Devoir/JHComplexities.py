import time
def getDetails(id):
    details_in = open("details.in.txt", 'r')
    p = int(details_in.readline())
    for i in range(p):
        line = details_in.readline()
        sep = line.split(',')
        if(sep[0] == id):
            details_in.close()
            return line.strip("\n")
    details_in.close()


start = time.time()
ids_in = open("ids.in.txt", 'r')
n = int(ids_in.readline())
for i in range(n):
    id = ids_in.readline()
    result = getDetails(id.strip())
    if result:
        print(result)
ids_in.close()
print("execution time : ", (time.time() - start))
